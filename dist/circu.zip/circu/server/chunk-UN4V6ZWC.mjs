import './polyfills.server.mjs';
import{a as p}from"./chunk-26NQVLWO.mjs";import{Ab as m,ha as i,yb as o,zb as r}from"./chunk-VLVHQGQR.mjs";var d=(()=>{let e=class e{};e.\u0275fac=function(n){return new(n||e)},e.\u0275cmp=i({type:e,selectors:[["app-request"]],decls:2,vars:0,template:function(n,a){n&1&&(o(0,"main"),m(1,"router-outlet"),r())},dependencies:[p]});let t=e;return t})();export{d as a};
