import './polyfills.server.mjs';
import{a}from"./chunk-UYFIRDFP.mjs";import"./chunk-FME56UVT.mjs";export{a as default};
