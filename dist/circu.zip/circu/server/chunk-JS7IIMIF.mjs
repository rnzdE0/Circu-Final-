import './polyfills.server.mjs';
import{a as p}from"./chunk-26NQVLWO.mjs";import{Ab as m,ha as n,yb as o,zb as r}from"./chunk-VLVHQGQR.mjs";var d=(()=>{let e=class e{};e.\u0275fac=function(i){return new(i||e)},e.\u0275cmp=n({type:e,selectors:[["app-list"]],decls:2,vars:0,template:function(i,a){i&1&&(o(0,"main"),m(1,"router-outlet"),r())},dependencies:[p]});let t=e;return t})();export{d as a};
