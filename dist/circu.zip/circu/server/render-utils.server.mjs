import './polyfills.server.mjs';
import{c as o,d as r,e as n}from"./chunk-LBGDTWQE.mjs";import"./chunk-HI34ILRH.mjs";import"./chunk-IZL4CD67.mjs";import{fc as e}from"./chunk-VLVHQGQR.mjs";import"./chunk-FME56UVT.mjs";export{n as renderApplication,r as renderModule,e as \u0275Console,o as \u0275SERVER_CONTEXT};
